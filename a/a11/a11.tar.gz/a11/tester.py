def testcmp(setup=None,       # setup (initialization before the test)
            s0="", s1=None,   # two python expressions for comparison
            cmp="==",         # how to compare s0, s1 (see below)
                              #   "=="             values are compared with ==
                              #   "!="             values are compared with !=
                              #   "in"
                              #   "not in"
                              #   "<", "<=", ">", ">="
                              #   "eq_list_as_set" compare the list from s0 and the list from s1 for
                              #                    equality as though they are sets
                              #   "subset_list_as_set" compare the list from s0 and the list from s1 for
                              #                    subset relation as though they are sets
                              #   "superset_list_as_set" compare the list from s0 and the list from s1 for
                              #                    superset relation as though they are sets
            verbose=True,     # True: report everything. False: report error(s)
            maxfail=1,        # number of failures before testing stops
            testrange=None,   # if verbose==True: testrange=[1, 5] means print the
                              #                   result only for test number in
                              #                   range(1, 5)
                              # if verbose==False: print only when there's an
                              #                    error
            numpass=[0],      # number of passes (don't change this)
            numfail=[0],      # number of failures (don't change these)
            print_setup=False 
            ):

    ts = [_.strip() for _ in setup.split('\n') if _.strip() != '']
    msg0 = ""
    if print_setup:
        if len(ts) > 0:
            msg0 += "setup : " + ts[0] + '\n'
            for _ in ts[1:]:
                msg0 += "        " + _ + '\n'
        else:
            msg0 += "setup :\n"
    for _ in ts:
        exec(_)
        
    msg0 += ("test  : %s %s %s" % (s0, cmp, s1)) + '\n'

    b0 = eval(s0)
    b1 = eval(s1)
    msg0 += "LHS   : %s  (type: %s)\nRHS   : %s  (type: %s)\n" % (b0, type(b0), b1, type(b1))
    if cmp == "==":
        b = b0 == b1
    elif cmp == "!=":
        b = b0 != b1
    elif cmp == "in":
        b = b0 != b1
    elif cmp == "not in":
        b = (b0 not in b1)
    elif cmp == "eq_list_as_set":
        b = all(x in b0 for x in b1) and all(x in b1 for x in b0)
    elif cmp == "subset_list_as_set":
        b = all(x in b1 for x in b0)
    elif cmp == "superset_list_as_set":
        b = all(x in b0 for x in b1)
    elif cmp == "<":
        b = b0 < b1
    elif cmp == "<=":
        b = b0 <= b1
    elif cmp == ">":
        b = b0 < b1
    elif cmp == ">=":
        b = b0 <= b1    
    else:
        raise ValueError("testcmp ERROR: unknown cmp %s" % cmp)
    
    if b:
        numpass[0] += 1
        msg0 += 'result: pass %s (PASS/FAIL/TOTAL: %s/%s/%s)\n' % (40*".", numpass[0], numfail[0], numpass[0] + numfail[0])
    else:
        numfail[0] += 1
        msg0 += 'result: FAIL %s (PASS/FAIL/TOTAL: %s/%s/%s)\n' % (40*".", numpass[0], numfail[0], numpass[0] + numfail[0])
    
    if verbose:
        if testrange == None:
            msg = msg0
        elif numpass[0] + numfail[0] in range(testrange[0], testrange[1]):
            msg = msg0
        else:
            msg = None
    else:
        if b: msg = None
        else: msg = msg0
        
    if msg: print(msg)
    if numfail[0] >= maxfail: raise Exception("max number of failures reached ... halting")



    
class Tester:
    """
    USAGE:
        t = Tester(setup="from PropositionalLogic import *\nP,Q,R,S,T = get_PropVars(['P','Q','R','S','T'])")
        t.testcmp("P", "P")
        t.testcmp("str(P)", "'P'")
        t.testcmp("P", "Q", cmp="!=")
    """
    def __init__(self,
                 setup="from PropositionalLogic import *\nP,Q,R,S,T = get_PropVars(['P','Q','R','S','T'])",
                 verbose=True,
                 maxfail=1,
                 testrange=None,
                 print_setup=False):
        self.setup = setup
        self.print_setup = print_setup
        self.verbose = verbose
        self.numpass = [0]
        self.numfail = [0]
        self.maxfail = maxfail
        self.testrange = testrange
    def testcmp(self,
                s0="", s1=None, 
                cmp="==",       
                setup=None):                 
        testcmp(setup=self.setup,
                s0=s0,
                s1=s1,
                cmp=cmp,
                verbose=self.verbose,
                maxfail=self.maxfail,
                testrange=self.testrange,
                numpass=self.numpass,
                numfail=self.numfail,
                print_setup=self.print_setup)
