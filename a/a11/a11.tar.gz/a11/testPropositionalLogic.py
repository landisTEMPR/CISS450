from PropositionalLogic import *
from tester import *

SETUP = """
from PropositionalLogic import *
P, Q, R, S, T = get_PropVars(['P', 'Q', 'R', 'S', 'T'])
"""
tester = Tester(setup=SETUP,       # Initialization before each test
                verbose=True,      # Change to False to reduce printing
                maxfail=1,         # Number of failures before halting
                testrange=None,    # If verbose==True and testrange=[2, 5], print test #2-#4 (i.e. "verbose for #2-#4")
                                   # If verbose==False, testrange is ignored
                print_setup=False) # If print_setup==True, setup is printed.
                                   #
                                   # USAGE:
                                   # * In general you want maxfail = 1.
                                   # * When debugging a new feature and you have written down 3 test cases for this feature,
                                   #   you might want to use maxfail = 3. To reduce output, check the test number of the
                                   #   3 test cases and set testrange to only print these three test cases.

def test(a, b, c=None, cmp='=='):           # SHORTHAND
    if c==None:                             #
        tester.testcmp(s0=a, s1=b, cmp=cmp) # 1. test("P", "P") for testing P == P
                                            #    test("[1,2,3]", "[2,3,2,1,3,1]", "eq_list_as_set") checks [1,2,3]
                                            #        is a subset of [2,3,2,1,3,1] and vice versa.
    else:                                   #
        tester.testcmp(setup=a, s0=b, s1=c) # 2. test("Z = get_PropVar('Z')", "Z", "Z") for testing Z == Z
                                            #    after creating Z

def test_PropVar():
    print(">>>> Testing PropVar")
    test("P", "P")
    test("str(P)", "'P'")
    test("P", "Q", cmp="!=")
    
def test_AND():
    print(">>>> Testing AND")
    test("str(AND(P,Q))", "'(P & Q)'")
    test("str(AND(AND(P, Q), R))", "'((P & Q) & R)'")
    test("str(AND(P, AND(Q, R)))", "'(P & (Q & R))'")

def test_OR():
    print(">>>> Testing OR")
    test("str(OR(P, Q))", "'(P | Q)'")
    test("str(OR(OR(P, Q), R))", "'((P | Q) | R)'")
    test("str(OR(P, OR(Q, R)))", "'(P | (Q | R))'")

def test_NOT():
    print(">>>> Testing NOT")
    test("str(NOT(P))", "'(~P)'")
    test("str(OR(OR(P, Q), R))", "'((P | Q) | R)'")
    test("str(OR(P, OR(Q, R)))", "'(P | (Q | R))'")

def test_IMPLIES():
    print(">>>> Testing IMPLIES")
    test("str(IMPLIES(P, P))", "'(P -> P)'")
    test("str(AND(P, IMPLIES(Q, R)))", "'(P & (Q -> R))'")
    test("str(OR(IMPLIES(P, Q), IMPLIES(P, R)))", "'((P -> Q) | (P -> R))'")

def test_IMPLIEDBY():
    print(">>>> Testing IMPLIEDBY")
    test("str(IMPLIEDBY(P, P))", "'(P <- P)'")
    test("str(AND(P, IMPLIEDBY(Q, R)))", "'(P & (Q <- R))'")
    test("str(OR(IMPLIEDBY(P, Q), IMPLIEDBY(P, R)))", "'((P <- Q) | (P <- R))'")

def test_BICOND():
    print(">>>> Testing BICOND")
    test("str(BICOND(P, P))", "'(P <-> P)'")
    test("str(AND(P, BICOND(Q, R)))", "'(P & (Q <-> R))'")
    test("str(OR(BICOND(P, Q), BICOND(P, R)))", "'((P <-> Q) | (P <-> R))'")

def test_VARIABLES():
    print(">>>> Testing VARIABLES")  
    test("VARIABLES(TRUE)", "set([])")
    test("VARIABLES(P)", "set([P])")
    test("VARIABLES(AND(P,Q))", "set([P, Q])")
    test("VARIABLES(OR(P,Q))", "set([P, Q])")    
    test("VARIABLES(NOT(P))", "set([P])")
    test("VARIABLES(NOT(NOT(P)))", "set([P])")
    test("VARIABLES(NOT(NOT(NOT(P))))", "set([P])")
    test("VARIABLES(AND(P, OR(P, P)))", "set([P])")
    test("VARIABLES(OR(AND(P,P), P))", "set([P])")
    test("VARIABLES(AND(OR(P,Q), P))", "set([P,Q])")
    test("VARIABLES(AND(AND(P,Q), AND(P, R)))", "set([P,Q,R])")
    test("VARIABLES(AND(AND(P,P), AND(P, AND(P, NOT(R)))))", "set([P,R])")

def test_LITERALS():
    print(">>>> Testing LITERALS")
    test("LITERALS(TRUE)", "[]")
    test("LITERALS(FALSE)", "[]")
    test("LITERALS(P)", "[P]")
    test("LITERALS(NOT(P))", "[NOT(P)]")
    test("LITERALS(AND(P, Q))", "[P, Q]", cmp='eq_list_as_set')
    test("LITERALS(AND(NOT(P), Q))", "[NOT(P), Q]", cmp='eq_list_as_set')
    test("LITERALS(AND(P, NOT(Q)))", "[P, NOT(Q)]", cmp='eq_list_as_set')
    test("LITERALS(AND(NOT(P), NOT(Q)))", "[NOT(P), NOT(Q)]", cmp='eq_list_as_set')
    test("LITERALS(AND(P, P))", "[P]", cmp='eq_list_as_set')
    test("LITERALS(AND(NOT(P), P))", "[NOT(P), P]", cmp='eq_list_as_set')
    test("LITERALS(AND(P, NOT(P)))", "[P, NOT(P)]", cmp='eq_list_as_set')
    test("LITERALS(AND(NOT(P), NOT(P)))", "[NOT(P)]", cmp='eq_list_as_set')
    test("LITERALS(OR(P, Q))", "[P, Q]", cmp='eq_list_as_set')
    test("LITERALS(OR(NOT(P), Q))", "[NOT(P), Q]", cmp='eq_list_as_set')
    test("LITERALS(OR(P, NOT(Q)))", "[P, NOT(Q)]", cmp='eq_list_as_set')
    test("LITERALS(OR(NOT(P), NOT(Q)))", "[NOT(P), NOT(Q)]", cmp='eq_list_as_set')
    test("LITERALS(OR(P, P))", "[P]", cmp='eq_list_as_set')
    test("LITERALS(OR(NOT(P), P))", "[NOT(P), P]", cmp='eq_list_as_set')
    test("LITERALS(OR(P, NOT(P)))", "[P, NOT(P)]", cmp='eq_list_as_set')
    test("LITERALS(OR(NOT(P), NOT(P)))", "[NOT(P), NOT(P)]", cmp='eq_list_as_set')
    
def test_ASSIGNMENT():
    print(">>>> Testing ASSIGNMENT")
    test("ASSIGNMENT([(P, TRUE)])", "{P:TRUE}")
    test("ASSIGNMENT([(P, FALSE)])", "{P:FALSE}")
    test("ASSIGNMENT([(P, FALSE), (P, TRUE)])", "{P:TRUE}")
    test("ASSIGNMENT([(P, TRUE), (Q, TRUE)])", "{P:TRUE, Q:TRUE}")
    test("ASSIGNMENT([(P, TRUE), (Q, FALSE)])", "{P:TRUE, Q:FALSE}")

def test_ASSIGNMENTS():
    print(">>>> Testing ASSIGNMENTS")
    test("list(ASSIGNMENTS(P))", "[{P:TRUE}, {P:FALSE}]")
    test("list(ASSIGNMENTS(NOT(P)))", "[{P:TRUE}, {P:FALSE}]")
    test("list(ASSIGNMENTS(AND(P, P)))", "[{P:TRUE}, {P:FALSE}]")
    test("list(ASSIGNMENTS(AND(P, AND(P, AND(P, Q)))))",
         "[{P:TRUE, Q:TRUE}, {P:TRUE, Q:FALSE}, {P:FALSE, Q:TRUE}, {P:FALSE, Q:FALSE}]",
         cmp="eq_list_as_set")

def test_SUBST():
    print(">>>> Testing SUBST")
    test("P.subst({})", "P")
    test("P.subst({P: TRUE})", "TRUE")
    test("P.subst({P: FALSE})",  "FALSE")
    test("P.subst({Q: TRUE})", "P")
    test("P.subst({Q: FALSE})", "P")
    test("SUBST({P: TRUE}, P)", "TRUE")
    test("SUBST({P: FALSE}, P)", "FALSE")
    test("SUBST({Q: TRUE}, P)", "P")
    test("SUBST({Q: FALSE}, P)", "P")
    
def test_SIMPLIFY():
    print(">>>> Testing SIMPLIFY")
    test("P.simplify()", "P")                         
    test("SIMPLIFY(P)", "P")
    
    # AND
    test("SIMPLIFY(AND(TRUE, TRUE))", "TRUE")                           #  1. TRUE & TRUE = TRUE    (redundant: see 9)
    test("SIMPLIFY(AND(TRUE, FALSE))", "FALSE")                         #  2. TRUE & FALSE = FALSE  (redundant: see 9)
    test("SIMPLIFY(AND(FALSE, TRUE))", "FALSE")                         #  3. FALSE & TRUE = FALSE  (redundant: see 11)
    test("SIMPLIFY(AND(FALSE, FALSE))", "FALSE")                        #  4. FALSE & FALSE = FALSE (redundant: see 11)
    test("SIMPLIFY(AND(P, P))", "P")                                    #  5. P & P = P
    test(SETUP + "; R = AND(P,Q)", "SIMPLIFY(AND(R, R))", "R")          #     (P & Q) & (P & Q) = P & Q
    test(SETUP + "; R = OR(P,Q)",  "SIMPLIFY(AND(R, R))", "R")          #     (P | Q) | (P | Q) = P | Q
    test(SETUP + "; R = NOT(P)",   "SIMPLIFY(AND(R, R))", "R")          #     (~P) | (~P) = ~P
    test(SETUP,                    "SIMPLIFY(AND(P, NOT(P)))", "FALSE") #  6. P & ~P = FALSE
    test(SETUP + "; R = AND(P,Q)", "SIMPLIFY(AND(R, NOT(R)))", "FALSE") #     (P & Q) & ~(P & Q) = TRUE
    test(SETUP + "; R = OR(P,Q)",  "SIMPLIFY(AND(R, NOT(R)))", "FALSE") #     (P | Q) & ~(P | Q) = TRUE
    test(SETUP + "; R = NOT(P)",   "SIMPLIFY(AND(R, NOT(R)))", "FALSE") #     (~P) & ~(~P) = TRUE
    test(SETUP,                    "SIMPLIFY(AND(NOT(P), P))", "FALSE") #  7. ~P & P = FALSE
    test(SETUP + "; R = AND(P,Q)", "SIMPLIFY(AND(NOT(R), R))", "FALSE") #     ~(P & Q) & (P & Q) = FALSE
    test(SETUP + "; R = OR(P,Q)",  "SIMPLIFY(AND(NOT(R), R))", "FALSE") #     ~(P | Q) & (P | Q) = FALSE
    test(SETUP + "; R = NOT(P)",   "SIMPLIFY(AND(NOT(R), R))", "FALSE") #     ~(~P) & (~P) = FALSE
    test(SETUP,                    "SIMPLIFY(AND(P, TRUE))", "P")       #  8. P & TRUE = P
    test(SETUP + "; R = AND(P,Q)", "SIMPLIFY(AND(R, TRUE))", "R")       #     (P & Q) | TRUE = TRUE
    test(SETUP + "; R = OR(P,Q)",  "SIMPLIFY(AND(R, TRUE))", "R")       #     (P | Q) | TRUE = TRUE
    test(SETUP + "; R = NOT(P)",   "SIMPLIFY(AND(R, TRUE))", "R")       #     (~P) | TRUE = TRUE
    test(SETUP,                    "SIMPLIFY(AND(TRUE, P))", "P")       #  9. TRUE & P = P
    test(SETUP + "; R = AND(P,Q)", "SIMPLIFY(AND(TRUE, R))", "R")       #     TRUE & (P & Q) = (P & Q)
    test(SETUP + "; R = OR(P,Q)",  "SIMPLIFY(AND(TRUE, R))", "R")       #     TRUE & (P | Q) = (P | Q)
    test(SETUP + "; R = NOT(P)",   "SIMPLIFY(AND(TRUE, R))", "R")       #     TRUE & (~P) = (~P)
    test(SETUP,                    "SIMPLIFY(AND(P, FALSE))", "FALSE")  # 10. P & FALSE = FALSE
    test(SETUP + "; R = AND(P,Q)", "SIMPLIFY(AND(R, FALSE))", "FALSE")  #     (P & Q) & FALSE = FALSE
    test(SETUP + "; R = OR(P,Q)",  "SIMPLIFY(AND(R, FALSE))", "FALSE")  #     (P | Q) & FALSE = FALSE
    test(SETUP + "; R = NOT(P)",   "SIMPLIFY(AND(R, FALSE))", "FALSE")  #     (~P) & FALSE = FALSE
    test(SETUP,                    "SIMPLIFY(AND(FALSE, P))", "FALSE")  # 11. FALSE & P = FALSE
    test(SETUP + "; R = AND(P,Q)", "SIMPLIFY(AND(FALSE, R))", "FALSE")  #     FALSE & (P & Q) = FALSE
    test(SETUP + "; R = OR(P,Q)",  "SIMPLIFY(AND(FALSE, R))", "FALSE")  #     FALSE & (P | Q) = FALSE
    test(SETUP + "; R = NOT(P)",   "SIMPLIFY(AND(FALSE, R))", "FALSE")  #     FALSE & (~P) = FALSE

    # OR
    test("SIMPLIFY(OR(TRUE, TRUE))", "TRUE")                          #  1. TRUE | TRUE = TRUE    (redundant: see 9)        
    test("SIMPLIFY(OR(TRUE, FALSE))", "TRUE")                         #  2. TRUE | FALSE = TRUE   (redundant: see 9)        
    test("SIMPLIFY(OR(FALSE, TRUE))", "TRUE")                         #  3. FALSE | TRUE = TRUE   (redundant: see 9)        
    test("SIMPLIFY(OR(FALSE, FALSE))", "FALSE")                       #  4. FALSE | FALSE = FALSE (redundant: see 9)
    test("SIMPLIFY(OR(P, P))", "P")                                   #  5. P | P = P
    test(SETUP + "; R = AND(P,Q)", "SIMPLIFY(OR(R, R))", "R")         #     (P & Q) | (P & Q) = P & Q
    test(SETUP + "; R = OR(P,Q)",  "SIMPLIFY(OR(R, R))", "R")         #     (P | Q) | (P | Q) = P | Q
    test(SETUP + "; R = NOT(P)",   "SIMPLIFY(OR(R, R))", "R")         #     (~P) | (~P) = ~P
    test(SETUP,                    "SIMPLIFY(OR(P, NOT(P)))", "TRUE") #  6. P | ~P = TRUE
    test(SETUP + "; R = AND(P,Q)", "SIMPLIFY(OR(R, NOT(R)))", "TRUE") #     (P & Q) | ~(P & Q) = TRUE
    test(SETUP + "; R = OR(P,Q)",  "SIMPLIFY(OR(R, NOT(R)))", "TRUE") #     (P | Q) | ~(P | Q) = TRUE
    test(SETUP + "; R = NOT(P)",   "SIMPLIFY(OR(R, NOT(R)))", "TRUE") #     (~P) | ~(~P) = TRUE
    test(SETUP,                    "SIMPLIFY(OR(NOT(P), P))", "TRUE") #  7. ~P | P = TRUE
    test(SETUP + "; R = AND(P,Q)", "SIMPLIFY(OR(NOT(R), R))", "TRUE") #     ~(P & Q) | (P & Q) = TRUE
    test(SETUP + "; R = OR(P,Q)",  "SIMPLIFY(OR(NOT(R), R))", "TRUE") #     ~(P | Q) | (P | Q) = TRUE
    test(SETUP + "; R = NOT(P)",   "SIMPLIFY(OR(NOT(R), R))", "TRUE") #     ~(~P) | (~P) = TRUE
    test(SETUP,                    "SIMPLIFY(OR(P, TRUE))", "TRUE")   #  8. P | TRUE = TRUE
    test(SETUP + "; R = AND(P,Q)", "SIMPLIFY(OR(R, TRUE))", "TRUE")   #     (P & Q) | TRUE = TRUE
    test(SETUP + "; R = OR(P,Q)",  "SIMPLIFY(OR(R, TRUE))", "TRUE")   #     (P | Q) | TRUE = TRUE
    test(SETUP + "; R = NOT(P)",   "SIMPLIFY(OR(R, TRUE))", "TRUE")   #     (~P) | TRUE = TRUE
    test("SIMPLIFY(OR(P, OR(Q, TRUE)))", "TRUE")                      #     P | (Q | TRUE) = TRUE
    test("SIMPLIFY(OR(OR(P, TRUE), Q))", "TRUE")                      #     (P | TRUE) | Q = TRUE
    test("SIMPLIFY(OR(P, OR(Q, OR(R, TRUE))))", "TRUE")               #     P | (Q | (R | TRUE)) = TRUE
    test("SIMPLIFY(OR(OR(P, OR(Q, TRUE)), R) )", "TRUE")              #     (P | (Q | TRUE)) | R) = TRUE
    test("SIMPLIFY(OR(P, OR(OR(Q, TRUE), R)))", "TRUE")               #     (P | ((Q | TRUE) | R)) = TRUE
    test("SIMPLIFY(OR(TRUE, P))", "TRUE")                             #  9. TRUE | P = TRUE
    test(SETUP + "; R = AND(P,Q)", "SIMPLIFY(OR(TRUE, R))", "TRUE")   #     TRUE | (P & Q) = TRUE
    test(SETUP + "; R = OR(P,Q)",  "SIMPLIFY(OR(TRUE, R))", "TRUE")   #     TRUE | (P | Q) = TRUE
    test(SETUP + "; R = NOT(P)",   "SIMPLIFY(OR(TRUE, R))", "TRUE")   #     TRUE | (~P) = TRUE
    test(SETUP,                    "SIMPLIFY(OR(P, FALSE))", "P")     # 10. P | FALSE = P
    test(SETUP + "; R = AND(P,Q)", "SIMPLIFY(OR(R, FALSE))", "R")     #     (P & Q) | FALSE = P & Q
    test(SETUP + "; R = OR(P,Q)",  "SIMPLIFY(OR(R, FALSE))", "R")     #     (P | Q) | FALSE = P | Q
    test(SETUP + "; R = NOT(P)",   "SIMPLIFY(OR(R, FALSE))", "R")     #     (~P) | FALSE = ~P
    test(SETUP,                    "SIMPLIFY(OR(FALSE, P))", "P")     # 11. FALSE | P = P
    test(SETUP + "; R = AND(P,Q)", "SIMPLIFY(OR(FALSE, R))", "R")     #     FALSE | (P & Q) = P & Q
    test(SETUP + "; R = OR(P,Q)",  "SIMPLIFY(OR(FALSE, R))", "R")     #     FALSE | (P | Q) = P | Q
    test(SETUP + "; R = NOT(P)",   "SIMPLIFY(OR(FALSE, R))", "R")     #     FALSE | (~P) = ~P
    test("SIMPLIFY(OR(P, OR(Q, OR(R, OR(S, OR(T, FALSE))))))", "OR(P, OR(Q, OR(R, OR(S, T))))") # P | (Q | (R | (S | (T | FALSE)))) = P | (Q | (R | (S | T)))
    
    # NOT
    test("SIMPLIFY(NOT(NOT(P)))", "P")                           # 1. ~(~P) = P
    test("SIMPLIFY(NOT(NOT(NOT(P))))", "NOT(P)")                 #    ~(~(~P) = ~P
    test("SIMPLIFY(NOT(NOT(NOT(NOT(P)))))", "P")                 #    ~(~(~(~P))) = P
    test("SIMPLIFY(NOT(NOT(AND(P, Q))))", "AND(P, Q)")           #    ~(~(P & Q)) = P & Q
    test("SIMPLIFY(AND(NOT(NOT(P)), Q))", "AND(P, Q)")           #    (~(~P)) & Q = P & Q
    test("SIMPLIFY(AND(P, NOT(NOT(Q))))", "AND(P, Q)")           #    P & (~(~Q)) = P & Q
    test("SIMPLIFY(AND(P, NOT(NOT(NOT(Q)))))", "AND(P, NOT(Q))") #    P & (~(~(~Q) = P & (~Q)
    test("SIMPLIFY(NOT(AND(P, Q)))", "OR(NOT(P), NOT(Q))")       # 2. ~(P & Q) = ~P | ~Q (de Morgan)
    test("SIMPLIFY(NOT(OR(P, Q)))", "AND(NOT(P), NOT(Q))")       # 3. ~(P | Q) = ~P & ~Q (de Morgan)

    # IMPLIES
    test("SIMPLIFY(IMPLIES(P, Q))", "OR(NOT(P), Q)")             # P -> Q = ~P | Q
    test("SIMPLIFY(IMPLIES(TRUE, Q))", "Q")                      # TRUE -> Q = Q
    test("SIMPLIFY(IMPLIES(FALSE, Q))", "TRUE")                  # FALSE -> Q = TRUE
    test("SIMPLIFY(IMPLIES(P, TRUE))", "TRUE")                   # P -> TRUE = TRUE
    test("SIMPLIFY(IMPLIES(P, P))", "TRUE")                      # P -> P = TRUE

    # IMPLIEDBY
    test("SIMPLIFY(IMPLIEDBY(P, Q))", "OR(NOT(Q), P)")           # P <- Q = ~Q | P 

    # BICOND
    test("SIMPLIFY(BICOND(P, Q))", "SIMPLIFY(AND(IMPLIES(P, Q), IMPLIES(Q,P)))") # P <-> Q = (~P | Q) & (~Q | P) 

def test_MODELS():
    print(">>>> Testing MODELS:")
    test("list(MODELS(P))", "[{P:TRUE}]")
    test("list(MODELS(NOT(P)))", "[{P:FALSE}]")
    test("list(MODELS(OR(P, NOT(P))))", "[{P:FALSE}, {P:TRUE}]", cmp="eq_list_as_set")
    test("list(MODELS(AND(P, Q)))", "[{P:TRUE, Q:TRUE}]", cmp="eq_list_as_set")

def test_SATISFIABLE():
    print(">>>> Testing SATISFIABLE:")
    test("SATISFIABLE(TRUE)", "True")
    test("SATISFIABLE(FALSE)", "False")
    test("SATISFIABLE(P)", "True")
    test("SATISFIABLE(AND(P, NOT(P)))", "False")
    test("SATISFIABLE(AND(P, Q))", "True")
    test("SATISFIABLE(IMPLIES(P, Q))", "True")
    test("SATISFIABLE(AND(IMPLIES(P, Q), IMPLIES(NOT(Q), NOT(P))))", "True")
    test("SATISFIABLE(AND(IMPLIES(P, Q), IMPLIES(NOT(Q), NOT(P))))", "True")

def test_is_LITERAL():
    print(">>>> Testing is_LITERAL:")
    test("is_LITERAL(TRUE)", "False")
    test("is_LITERAL(FALSE)", "False")
    test("is_LITERAL(P)", "True")
    test("is_LITERAL(NOT(P))", "True")
    test("is_LITERAL(NOT(NOT(P)))", "False")
    test("is_LITERAL(AND(P, Q))", "False")
    test("is_LITERAL(OR(P, Q))", "False")
    test("is_LITERAL(IMPLIES(P, Q))", "False")
    test("is_LITERAL(IMPLIEDBY(P, Q))", "False")
    test("is_LITERAL(BICOND(P, Q))", "False")
    test("is_LITERAL(XOR(P, Q))", "False")

def test_is_CNF_clause():
    print(">>>> Testing is_CNF_clause:")
    test("is_CNF_clause(TRUE)", "False")
    test("is_CNF_clause(FALSE)", "False")
    test("is_CNF_clause(P)", "True")
    test("is_CNF_clause(NOT(P))", "True")
    test("is_CNF_clause(OR(P, Q))", "True")
    test("is_CNF_clause(AND(P, Q))", "False")
    test("is_CNF_clause(OR(NOT(P), Q))", "True")
    test("is_CNF_clause(AND(NOT(P), Q))", "False")
    test("is_CNF_clause(OR(P, NOT(Q)))", "True")
    test("is_CNF_clause(AND(P, NOT(Q)))", "False")
    test("is_CNF_clause(OR(NOT(P), NOT(Q)))", "True")
    test("is_CNF_clause(AND(NOT(P), NOT(Q)))", "False")
    test("is_CNF_clause(OR(P, OR(Q, R)))", "True")
    test("is_CNF_clause(AND(P, OR(Q, R)))", "False")
    test("is_CNF_clause(OR(P, AND(Q, R)))", "False")
    test("is_CNF_clause(AND(P, AND(Q, R)))", "False")
    test("is_CNF_clause(OR(NOT(P), OR(Q, R)))", "True")
    test("is_CNF_clause(AND(NOT(P), OR(Q, R)))", "False")
    test("is_CNF_clause(OR(NOT(P), AND(Q, R)))", "False")
    test("is_CNF_clause(AND(NOT(P), AND(Q, R)))", "False")
    test("is_CNF_clause(OR(P, OR(NOT(Q), R)))", "True")
    test("is_CNF_clause(AND(P, OR(NOT(Q), R)))", "False")
    test("is_CNF_clause(OR(P, AND(NOT(Q), R)))", "False")
    test("is_CNF_clause(AND(P, AND(NOT(Q), R)))", "False")        
    test("is_CNF_clause(OR(P, OR(Q, NOT(R))))", "True")
    test("is_CNF_clause(AND(P, OR(Q, NOT(R))))", "False")
    test("is_CNF_clause(OR(P, AND(Q, NOT(R))))", "False")
    test("is_CNF_clause(AND(P, AND(Q, NOT(R))))", "False")
    test("is_CNF_clause(OR(NOT(P), OR(NOT(Q), R)))", "True")
    test("is_CNF_clause(AND(NOT(P), OR(NOT(Q), R)))", "False")
    test("is_CNF_clause(OR(NOT(P), AND(NOT(Q), R)))", "False")
    test("is_CNF_clause(AND(NOT(P), AND(NOT(Q), R)))", "False")
    test("is_CNF_clause(OR(NOT(P), OR(Q, NOT(R))))", "True")
    test("is_CNF_clause(AND(NOT(P), OR(Q, NOT(R))))", "False")
    test("is_CNF_clause(OR(NOT(P), AND(Q, NOT(R))))", "False")
    test("is_CNF_clause(AND(NOT(P), AND(Q, NOT(R))))", "False")
    test("is_CNF_clause(OR(P, OR(Q, R)))", "True")
    test("is_CNF_clause(AND(P, OR(Q, R)))", "False")
    test("is_CNF_clause(OR(P, AND(Q, R)))", "False")
    test("is_CNF_clause(AND(P, AND(Q, R)))", "False")
    test("is_CNF_clause(OR(NOT(P), OR(NOT(Q), NOT(R))))", "True")
    test("is_CNF_clause(AND(NOT(P), OR(NOT(Q), NOT(R))))", "False")
    test("is_CNF_clause(OR(NOT(P), AND(NOT(Q), NOT(R))))", "False")
    test("is_CNF_clause(AND(NOT(P), AND(NOT(Q), NOT(R))))", "False")
    test("is_CNF_clause(OR(OR(P, Q), R))", "True")
    test("is_CNF_clause(AND(OR(P, Q), R))", "False")
    test("is_CNF_clause(OR(AND(P, Q), R))", "False")
    test("is_CNF_clause(AND(AND(P, Q), R))", "False")
    test("is_CNF_clause(OR(OR(NOT(P), Q), R))", "True")
    test("is_CNF_clause(AND(OR(NOT(P), Q), R))", "False")
    test("is_CNF_clause(OR(AND(NOT(P), Q), R))", "False")
    test("is_CNF_clause(AND(AND(NOT(P), Q), R))", "False")
    test("is_CNF_clause(OR(OR(P, NOT(Q)), R))", "True")
    test("is_CNF_clause(AND(OR(P, NOT(Q)), R))", "False")
    test("is_CNF_clause(OR(AND(P, NOT(Q)), R))", "False")
    test("is_CNF_clause(AND(AND(P, NOT(Q)), R))", "False")
    test("is_CNF_clause(OR(OR(P, Q), NOT(R)))", "True")
    test("is_CNF_clause(AND(OR(P, Q), NOT(R)))", "False")
    test("is_CNF_clause(OR(AND(P, Q), NOT(R)))", "False")
    test("is_CNF_clause(AND(AND(P, Q), NOT(R)))", "False")
    test("is_CNF_clause(OR(OR(NOT(P), NOT(Q)), R))", "True")
    test("is_CNF_clause(AND(OR(NOT(P), NOT(Q)), R))", "False")
    test("is_CNF_clause(OR(AND(NOT(P), NOT(Q)), R))", "False")
    test("is_CNF_clause(AND(AND(NOT(P), NOT(Q)), R))", "False")
    test("is_CNF_clause(OR(OR(NOT(P), Q), NOT(R)))", "True")
    test("is_CNF_clause(AND(OR(NOT(P), Q), NOT(R)))", "False")
    test("is_CNF_clause(OR(AND(NOT(P), Q), NOT(R)))", "False")
    test("is_CNF_clause(AND(AND(NOT(P), Q), NOT(R)))", "False")
    test("is_CNF_clause(OR(OR(P, NOT(Q)), NOT(R)))", "True")
    test("is_CNF_clause(AND(OR(P, NOT(Q)), NOT(R)))", "False")
    test("is_CNF_clause(OR(AND(P, NOT(Q)), NOT(R)))", "False")
    test("is_CNF_clause(AND(AND(P, NOT(Q)), NOT(R)))", "False")
    test("is_CNF_clause(OR(OR(NOT(P), NOT(Q)), NOT(R)))", "True") 
    test("is_CNF_clause(AND(OR(NOT(P), NOT(Q)), NOT(R)))", "False")
    test("is_CNF_clause(OR(AND(NOT(P), NOT(Q)), NOT(R)))", "False")
    test("is_CNF_clause(AND(AND(NOT(P), NOT(Q)), NOT(R)))", "False")

def test_is_CNF():
    print(">>>> Testing is_CNF:")
    test("is_CNF(TRUE)", "False")
    test("is_CNF(FALSE)", "False")
    test("is_CNF(P)", "True")
    test("is_CNF(NOT(P))", "True")

    test("is_CNF(AND(P, Q))", "True")
    test("is_CNF(AND(NOT(P), Q))", "True")
    test("is_CNF(AND(P, NOT(Q)))", "True")
    test("is_CNF(AND(NOT(P), NOT(Q)))", "True")

    test("is_CNF(AND(TRUE, Q))", "False")
    test("is_CNF(AND(P, TRUE))", "False")
    test("is_CNF(AND(TRUE, TRUE))", "False")
    test("is_CNF(AND(NOT(TRUE), Q))", "False")
    test("is_CNF(AND(NOT(P), TRUE))", "False")
    test("is_CNF(AND(TRUE, NOT(Q)))", "False")
    test("is_CNF(AND(P, NOT(TRUE)))", "False")
    test("is_CNF(AND(NOT(TRUE), NOT(Q)))", "False")
    test("is_CNF(AND(NOT(P), NOT(TRUE)))", "False")
    test("is_CNF(AND(NOT(TRUE), NOT(TRUE)))", "False")

    test("is_CNF(OR(P, Q))", "True")
    test("is_CNF(OR(NOT(P), Q))", "True")
    test("is_CNF(OR(P, NOT(Q)))", "True")
    test("is_CNF(OR(NOT(P), NOT(Q)))", "True")

    test("is_CNF(AND(AND(P, Q), R))", "True")                # (P & Q) & R     1,2 & & checked 
    test("is_CNF(AND(AND(NOT(P), Q), R))", "True")           # (~P & Q) & R    1,2 & & checked
    test("is_CNF(AND(AND(P, NOT(Q)), R))", "True")           # (P & ~Q) & R    1,2 & & checked
    test("is_CNF(AND(AND(P, Q), NOT(R)))", "True")           # (P & Q) & ~R    1,2 & & checked
    test("is_CNF(AND(AND(NOT(P), NOT(Q)), R))", "True")      # (~P & ~Q) & R   1,2 & & checked
    test("is_CNF(AND(AND(NOT(P), Q), NOT(R)))", "True")      # (~P & Q) & ~R   1,2 & & checked
    test("is_CNF(AND(AND(NOT(P), NOT(Q)), NOT(R)))", "True") # (~P & ~Q) & ~R  1,2 & & checked
    test("is_CNF(OR(AND(P, Q), R))", "False")                # (P & Q) | R     1,2 & | checked CNF = (P | R) & (Q | R)
    test("is_CNF(OR(AND(NOT(P), NOT(Q)), NOT(R)))", "False") # (~P & ~Q) | ~R) 1,2 & | checked CNF = (~P | ~R) & (~Q | ~R)
    test("is_CNF(AND(OR(P, Q), R))", "True")                 # (P | Q) & R     1,2 | & checked
    test("is_CNF(AND(OR(NOT(P), Q), R))", "True")            # (~P | Q) & R    1,2 | & checked
    test("is_CNF(AND(OR(P, NOT(Q)), R))", "True")            # (P | ~Q) & R    1,2 | & checked
    test("is_CNF(AND(OR(P, Q), NOT(R)))", "True")            # (P | Q) & ~R    1,2 | & checked
    test("is_CNF(AND(OR(NOT(P), Q), NOT(R)))", "True")       # (~P | Q) & ~R   1,2 | & checked
    test("is_CNF(AND(OR(NOT(P), NOT(Q)), NOT(R)))", "True")  # (~P | ~Q) & ~R  1,2 | & checked

    test("is_CNF(AND(P, AND(Q, R)))", "True")                # P & (Q & R)     2,1 & & 
    test("is_CNF(AND(NOT(P), AND(Q, R)))", "True")           # ~P & (~Q & R)   2,1 & & 
    test("is_CNF(AND(P, AND(NOT(Q), R)))", "True")           # P & (~Q & R)    2,1 & & 
    test("is_CNF(AND(P, AND(Q, NOT(R))))", "True")           # P & (Q & ~R)    2,1 & & 
    test("is_CNF(AND(NOT(P), AND(NOT(Q), R)))", "True")      # ~P & (~Q & R)   2,1 & & 
    test("is_CNF(AND(NOT(P), AND(Q, NOT(R))))", "True")      # P & (Q & ~R)    2,1 & & 
    test("is_CNF(AND(P, AND(NOT(Q), NOT(R))))", "True")      # P & (~Q & ~R)   2,1 & & 
    test("is_CNF(AND(NOT(P), AND(NOT(Q), NOT(R))))", "True") # ~P & (~Q & ~R)  2,1 & &
    test("is_CNF(AND(P, OR(Q, R)))", "True")                 # P & (Q | R)     2,1 & |
    test("is_CNF(OR(NOT(P), AND(NOT(Q), NOT(R))))", "False") # ~P | (~Q & ~R)  2,1 | & CNF = (~Q | ~P) & (~R | ~P)
    test("is_CNF(OR(P, AND(Q, R)))", "False")                # P | (Q & R)     2,1 | & CNF = (Q | P) & (R | P)
    
    test("is_CNF(AND(AND(AND(P, Q), R), S))", "True")        # (((P & Q) & R) & S) 1,2,3 & & & checked
    test("is_CNF(OR(AND(AND(P, Q), R), S))", "False")        # (((P & Q) & R) | S) 1,2,3 & & | checked
    test("is_CNF(AND(OR(AND(P, Q), R), S))", "False")        # (((P & Q) | R) & S) 1,2,3 & | & checked
    test("is_CNF(AND(AND(OR(P, Q), R), S))", "True")         # (((P | Q) & R) & S) 1,2,3 | & & checked 
    test("is_CNF(OR(OR(AND(P, Q), R), S))", "False")         # (((P & Q) | R) | S) 1,2,3 & | | checked CNF = (P | R | S) & (Q | R | S)
    test("is_CNF(OR(AND(OR(P, Q), R), S))", "False")         # (((P | Q) & R) | S) 1,2,3 | & | checked CNF = (P | Q | S) & (R | S)
    test("is_CNF(AND(OR(OR(P, Q), R), S))", "True")          # (((P | Q) | R) & S) 1,2,3 | | & checked
    test("is_CNF(OR(OR(OR(P, Q), R), S))", "True")           # (((P | Q) | R) | S) 1,2,3 | | | checked
    
    test("is_CNF(AND(AND(P, Q), AND(R, S)))", "True")        # ((P & Q) & (R & S)) 1,3,2 & & & checked
    test("is_CNF(AND(AND(P, Q), OR(R, S)))", "True")         # ((P & Q) & (R | S)) 1,3,2 & & | checked
    test("is_CNF(OR(AND(P, Q), AND(R, S)))", "False")        # ((P & Q) | (R & S)) 1,3,2 & | & checked
    test("is_CNF(AND(OR(P, Q), AND(R, S)))", "True")         # ((P | Q) & (R & S)) 1,3,2 | & & checked
    test("is_CNF(OR(OR(AND(P, Q), R), S))", "False")         # (((P & Q) | R) | S) 1,3,2 & | | checked CNF = (P | R | S) & (Q | R | S)
    test("is_CNF(OR(AND(OR(P, Q), R), S))", "False")         # (((P | Q) & R) | S) 1,3,2 | & | checked CNF = (P | Q | S) & (R | S)
    test("is_CNF(AND(OR(OR(P, Q), R), S))", "True")          # (((P | Q) | R) & S) 1,3,2 | | & checked
    test("is_CNF(AND(OR(OR(P, Q), R), S))", "True")          # (((P | Q) | R) | S) 1,3,2 | | | checked
    
    test("is_CNF(AND(AND(P, AND(Q, R)), S))", "True")        # ((P & (Q & R)) & S) 2.1.3 & & & checked
    test("is_CNF(OR(AND(P, AND(Q, R)), S))", "False")        # ((P & (Q & R)) | S) 2,1,3 & & | checked CNF = (P | S) & (Q | S) & (R | S)
    test("is_CNF(AND(AND(P, OR(Q, R)), S))", "True")         # ((P & (Q | R)) & S) 2,1,3 & | & checked
    test("is_CNF(AND(OR(P, AND(Q, R)), S))", "False")        # ((P | (Q & R)) & S) 2,1,3 | & & checked CNF = (Q | P) & (R | P) & S
    test("is_CNF(OR(AND(P, OR(Q, R)), S))", "False")         # ((P & (Q | R)) | S) 2,1,3 & | | checked CNF = (P | S) & (Q | R | S)
    test("is_CNF(OR(OR(P, AND(Q, R)), S))", "False")         # ((P | (Q & R)) | S) 2,1,3 | & | checked CNF = (Q | P | S) & (R | P | S)
    test("is_CNF(AND(OR(P, OR(Q, R)), S))", "True")          # ((P | (Q | R)) & S) 2,1,3 | | & checked 
    test("is_CNF(OR(OR(P, OR(Q, R)), S))", "True")           # ((P | (Q | R)) | S) 2,1,3 | | | checked 

    test("is_CNF(AND(P, AND(AND(Q, R), S)))", "True")        # (P & ((Q & R) & S)) 2.3.1 & & & checked
    test("is_CNF(AND(P, OR(AND(Q, R), S)))", "False")        # (P & ((Q & R) | S)) 2,3,1 & & | checked CNF = P & (Q | S) & (R | S)
    test("is_CNF(AND(P, AND(OR(Q, R), S)))", "True")         # (P & ((Q | R) & S)) 2,3,1 & | & checked
    test("is_CNF(OR(P, AND(AND(Q, R), S)))", "False")        # (P | ((Q & R) & S)) 2,3,1 | & & checked CNF = (Q | P) & (R | P) & (S | P)
    test("is_CNF(AND(P, OR(OR(Q, R), S)))", "True")          # (P & ((Q | R) | S)) 2,3,1 & | | checked 
    test("is_CNF(OR(P, OR(AND(Q, R), S)))", "False")         # (P | ((Q & R) | S)) 2,3,1 | & | checked CNF = (Q | S | P) & (R | S | P)
    test("is_CNF(OR(P, AND(OR(Q, R), S)))", "False")         # (P | ((Q | R) & S)) 2,3,1 | | & checked CNF = (Q | R | P) & (S | P)
    test("is_CNF(OR(P, OR(OR(Q, R), S)))", "True")           # (P | ((Q | R) | S)) 2,3,1 | | | checked 
    
    test("is_CNF(AND(AND(P, Q), AND(R, S)))", "True")        # ((P & Q) & (R & S)) 3,1,2 & & & checked same as 1,3,2 & & &
    test("is_CNF(AND(AND(P, Q), OR(R, S)))", "True")         # ((P & Q) & (R | S)) 3,1,2 & & | checked
    test("is_CNF(OR(AND(P, Q), AND(R, S)))", "False")        # ((P & Q) | (R & S)) 3,1,2 & | & checked CNF = (R | P) & (S | P) & (R | Q) & (S | Q)
    test("is_CNF(AND(OR(P, Q), AND(R, S)))", "True")         # ((P | Q) & (R & S)) 3,1,2 | & & checked 
    test("is_CNF(OR(AND(P, Q), OR(R, S)))", "False")         # ((P & Q) | (R | S)) 3,1,2 & | | checked CNF = (P | R | S) & (Q | R | S)
    test("is_CNF(AND(OR(P, Q), OR(R, S)))", "True")          # ((P | Q) & (R | S)) 3,1,2 | & | checked
    test("is_CNF(OR(OR(P, Q), AND(R, S)))", "False")         # ((P | Q) | (R & S)) 3,1,2 | | & checked CNF = (R | P | Q) & (S | P | Q)
    test("is_CNF(OR(OR(P, Q), OR(R, S)))", "True")           # ((P | Q) | (R | S)) 3,1,2 | | | checked 
    
    test("is_CNF(AND(P, AND(Q, AND(R, S))))", "True")        # (P & (Q & (R & S))) 3,2,1 & & & checked
    test("is_CNF(AND(P, AND(Q, OR(R, S))))", "True")         # (P & (Q & (R | S))) 3,2,1 & & | checked
    test("is_CNF(AND(P, OR(Q, AND(R, S))))", "False")        # (P & (Q | (R & S))) 3,2,1 & | & checked CNF = P & (R | Q) & (S | Q)
    test("is_CNF(OR(P, AND(Q, AND(R, S))))", "False")        # (P | (Q & (R & S))) 3,2,1 | & & checked CNF = (Q ∨ P) ∧ (R ∨ P) ∧ (S ∨ P)
    test("is_CNF(AND(P, OR(Q, OR(R, S))))", "True")          # (P & (Q | (R | S))) 3,2,1 & | | checked 
    test("is_CNF(OR(P, AND(Q, OR(R, S))))", "False")         # (P | (Q & (R | S))) 3,2,1 | & | checked CNF = (Q | P) & (R | S | P)
    test("is_CNF(OR(P, OR(Q, AND(R, S))))", "False")         # (P | (Q | (R & S))) 3,2,1 | | & checked CNF = (R | Q | P) & (S | Q | P)
    test("is_CNF(OR(P, OR(Q, OR(R, S))))", "True")           # (P | (Q | (R | S))) 3,2,1 | | | checked 
    
if __name__ == '__main__':

    test_PropVar()
    test_AND()
    test_OR()
    test_NOT()
    test_IMPLIES()
    test_IMPLIEDBY()
    test_BICOND()
    test_VARIABLES()
    test_LITERALS()
    test_ASSIGNMENT()
    test_ASSIGNMENTS()
    test_SUBST()
    test_SIMPLIFY()
    test_MODELS()
    test_SATISFIABLE()
    test_is_LITERAL()    # optional
    test_is_CNF_clause() # optional
    test_is_CNF() # optional

