"""
Propositional Logic
Y. Liow

USAGE:
    from PropLogic import *
    p = PropVar('p')
    q = PropVar('q')
    e1 = AND(p, q)
    a = ASSIGNMENT([p, TRUE])
    e2 = e1.subst(a)
    if (e2 == TRUE):
        print("true")
    else:
        print("not true")

Grammar of propositional sentence
---------------------------------
PropSentence -> Atom
              | ComplexSentence
Atom -> Constant
      | Variable
ComplexSentence -> PropSentence AND PropSentence
                 | PropSentence OR PropSentence
                 | NOT PropSentence
                 | PropSentence XOR PropSentence
                 | PropSentence IMPLIES PropSentence
                 | PropSentence IMPLIEDBY PropSentence
                 | PropSentence BICOND PropSentence

Two propositional sentences are "equal" in different ways:
- equal as expressions: P = P, P & Q = P AND Q. But P & Q is not Q & P
- equal as in "equivalent": e1 = e2 for all assignments, i.e., e1 <-> e2 is a tautology.
"""

import sys, copy
import itertools

class PropSentence:
    def __init__(self, name=None):
        self.name = name
    def __str__(self):
        return self.name
    def __repr__(self):
        return str(self.name)
    def __hash__(self):
        return hash(self.name)
    def __eq__(self, p):
        return self.name == p.name
    def subst(self, assignment):
        raise NotImplementedError
    def variables(self):
        raise NotImplementedError
    def simplify(self):
        raise NotImplementedError

class DuplicateAtomicSentence(BaseException):
    def __init__(self): BaseException.__init__(self)

class AtomicSentence(PropSentence):
    """
    WARNING: AtomicSentences are identified by their names.
    """
    atoms = {}
    def __init__(self, name):
        PropSentence.__init__(self, name)
        if name in AtomicSentence.atoms:
            print("AtomicSentence: WARNING! Duplicate AtomicSentence created with name %s" % name)
        else:
            AtomicSentence.atoms[name] = self
    def __del__(self):
        if self.name in AtomicSentence.atoms:
            del AtomicSentence.atoms[self.name]

def get_PropVar(s):
    if s not in AtomicSentence.atoms:
        P = PropVar(s)
    return AtomicSentence.atoms[s]

def get_PropVars(ss):
    return [get_PropVar(s) for s in ss]
            
class ComplexSentence(PropSentence):
    def __init__(self, opname, operands):
        assert len(operands) in [1, 2] # only unary and binary
        if len(operands) == 1:
            name = "(%s%s)" % (opname, operands[0])
        elif len(operands) == 2:
            name = "(%s %s %s)" % (operands[0], opname, operands[1])
        PropSentence.__init__(self, name=name)
        self.opname = opname
        self.operands = operands
    def __str__(self):
        return self.name
    def __repr__(self):
        return str(self)
    def __getitem__(self, i):
        return self.operands[i]
    def __setitem__(self, i, val): # WARNING: Dangerous
        self.operands[i] = val
    def variables(self):
        ret = set([])
        for op in self.operands:
            a = op.variables()
            ret |= a
        return ret
        
class Constant(AtomicSentence):
    def __init__(self, name):
        AtomicSentence.__init__(self, name)
    def subst(self, assignment):
        return self
    def variables(self):
        return set([])
    def simplify(self):
        return self
    
TRUE = Constant("TRUE")
FALSE = Constant("FALSE")

class PropVar(AtomicSentence):
    def __init__(self, name):
        AtomicSentence.__init__(self, name)
    def variables(self):
        return set([self])
    def subst(self, assignment):
        if self in assignment:
            return assignment[self]
        else:
            return self
    def simplify(self):
        return self
    
class NOT(ComplexSentence):
    def __init__(self, x):
        ComplexSentence.__init__(self, '~', [x])

class AND(ComplexSentence):
    def __init__(self, x, y):
        ComplexSentence.__init__(self, '&', [x, y])
    def subst(self, assignment):
        return AND(self[0].subst(assignment), self[1].subst(assignment))
    def simplify(self):
        left,right = self.operands
        if left == TRUE:              # TRUE & Q = Q
            return right.simplify()            
        elif left == FALSE:           # FALSE & Q = FALSE
            return FALSE            
        elif right == TRUE:           # P & TRUE = P
            return left.simplify()
        elif right == FALSE:          # P & FALSE = FALSE
            return FALSE
        elif left == right:           # P & P = P
            return left.simplify()
        elif isinstance(left, NOT) and left[0] == right:   # ~P & P = FALSE
            return FALSE
        elif isinstance(right, NOT) and right[0] == left:  # P & ~P = FALSE
            return FALSE
        else:
            left1 = left.simplify()
            right1 = right.simplify()
            if left == left1 and right == right1:
                return AND(left1, right1)
            else:
                return AND(left1, right1).simplify()
                
class OR(ComplexSentence):
    def __init__(self, x, y):
        ComplexSentence.__init__(self, '|', [x, y])
        
class XOR(ComplexSentence):
    def __init__(self, x, y):
        ComplexSentence.__init__(self, '^', [x, y])

class IMPLIES(ComplexSentence):
    def __init__(self, x, y):
        ComplexSentence.__init__(self, '->', [x, y])

class IMPLIEDBY(ComplexSentence):
    def __init__(self, x, y):
        ComplexSentence.__init__(self, '<-', [x, y])

class BICOND(ComplexSentence):
    def __init__(self, x, y):
        ComplexSentence.__init__(self, '<->', [x, y])

#==============================================================================
# Various algorithms
#==============================================================================
def VARIABLES(expr):
    """ returns a set of propositional variables in the expr """
    assert isinstance(expr, PropSentence)
    e = copy.deepcopy(expr)
    return e.variables()

def LITERALS(expr):
    """ Returns list of unique literals in expr """
    return None

def ASSIGNMENT(xs):
    """ Creates a dictionary of (PropVar, Constant).
    xs is a list of (PropVar, Constant) or already a dictionary """
    if isinstance(xs, dict):
        for key in xs:
            if not isinstance(key, PropVar):
                raise ValueError("ASSIGNMENT ERROR: key %s is not PropVar" % key)
            if xs[key] not in [TRUE, FALSE]:
                raise ValueError("ASSIGNMENT ERROR: value %s is not TRUE/FALSE" % xs[key])
        d = xs
    else:
        d = {}
        for key, val in xs:
            if not isinstance(key, PropVar):
                raise ValueError("ASSIGNMENT ERROR: key %s is not PropVar" % key)
            if val not in [TRUE, FALSE]:
                raise ValueError("ASSIGNMENT ERROR: value %s is not TRUE/FALSE" % val)
            d[key] = val
    return d

def ASSIGNMENTS(vars_or_expr):
    """ A generator for all assignments given list/set of variables or an expr """
    if isinstance(vars_or_expr, PropSentence):
        vars = VARIABLES(vars_or_expr)
    elif isinstance(vars_or_expr, (list, set)) and \
         all(isinstance(x, PropVar) for x in vars_or_expr):
        vars = vars_or_expr
    else:
        raise ValueError("%s is not PropSentence and is not list of PropVars" % vars_or_expr)  
    n = len(vars)
    gen = itertools.product([TRUE, FALSE], repeat=n)
    for values in gen:
        vs = zip(vars, values)
        vs = list(vs)
        yield ASSIGNMENT(vs)

def SUBST(assignment, expr):
    """ Subtitutes values in assignment to expr. Does not simplify. """
    return expr.subst(assignment)

def SIMPLIFY(expr):
    """
    Simplify must also include removing XOR, ->, <-, <-> (i.e., replace by
    AND, OR, NOT).
    Also ~(P & Q) = ~P | ~Q and inverse (de Morgan)
    """
    return expr.simplify()

def EQUIVALENT(e1, e2):
    """ Returns TRUE iff expr1 and expr2 are equivalent (in the logic sense) """
    return NotImplementedError

def SATISFIABLE(expr):
    """ Return TRUE if expr is satisfiable (in the logic sense) """
    return NotImplementedError

def IS_TAUTOLOGY(expr):
    """ Return TRUE if expr is a tautology (in the logic sense) """
    return NotImplementedError
    
def MODELS(expr):
    """ Generator of assignments such that
    SIMPLIFY(SUBST(assignment, expr)) is TRUE"""
    vars_ = VARIABLES(expr)
    for assignment in ASSIGNMENTS(vars_):
        if expr.subst(assignment).simplify() == TRUE:
            yield assignment
        
def TT_ENTAILS(expr1, expr2):
    """
    Brute force entails.
    e1 entails e2 iff if M is a model for e1, then M is a model for e2
    (For PL_RESOLVE optimization, see KnowledgeBase class.)
    """
    for model in MODELS(expr1):
        if expr2.subst(model).simplify() != TRUE:
            return FALSE
    return TRUE

def CNF(expr):
    return NotImplementedError

class KnowledgeBase:
    def __init__(self):
        return NotImplementedError
    def tell(self, e):
        return NotImplementedError
    def ask(self, e):
        """
        Use propositional logic resolution.
        (You might try to write a TT-entails first as an experiment and then
        use it to test against your PL resolution algorithm.)
        """
        return NotImplementedError
        
if __name__ == '__main__':
    pass
